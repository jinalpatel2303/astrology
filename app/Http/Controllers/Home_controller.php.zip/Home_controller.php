<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;
use App\Models\Admin;
use DB;

use App\Http\Controllers\DateTime;
use Carbon\Carbon;

class Home_controller extends Controller
{
    public function index(){

        $data['home_banner']=DB::table('home_banner')->get();

        $data['home_about_description']=DB::table('home_about_description')->get();

        $data['home_about']=DB::table('home_about')->get();

        $data['home_blog_description']=DB::table('home_blog_description')->get();

        $data['blog_detail']=DB::table('blog_detail') ->inRandomOrder()->limit(3)->get();

        $home_faq_description=DB::table('home_faq_description')->get();

        $data['faq_image']=$home_faq_description[0]->image;

        $data['faq_bg_image']=$home_faq_description[0]->bg_image;

        $data['home_faq']=DB::table('home_faq')->get();

        $data['home_demo']=DB::table('home_demo')->get();

        $data['home_testimonial_description']=DB::table('home_testimonial_description')->get();

        $data['home_testimonial']=DB::table('home_testimonial')->where('status',1)->get();

        $data['header_offer']=DB::table('header_offer')->get();

        $data['home_product_des']=DB::table('home_product_des')->get();
        
        $data['home_advertise']=DB::table('home_advertise')->get();

        $data['product']=DB::table('product')->get();

        $data['product_image']=DB::table('product_image')->get();




        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('index',$data);
    }




    public function about_us(){

        $data['banner_image']=DB::table('banner_image')->where('page_name','aboutus')->get();

        $data['aboutus_about_description']=DB::table('aboutus_about_description')->get();

        $data['aboutus_about']=DB::table('aboutus_about')->get();

        $aboutus_occult=DB::table('aboutus_occult')->get();

        $data['occult_banner']=$aboutus_occult[0]->bg_image;

        $data['aboutus_occult']=DB::table('aboutus_occult')->get();

        $data['aboutus_astronomy_description']=DB::table('aboutus_astronomy_description')->get();

        $data['aboutus_detail']=DB::table('aboutus_detail')->get();

        $data['home_demo']=DB::table('home_demo')->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('about_us',$data);
    }




    public function blog(){

        $data['banner_image']=DB::table('banner_image')->where('page_name','blog')->get();

        $data['blog_detail']=DB::table('blog_detail')->paginate(3);

        $data['blog_detail_sb']=DB::table('blog_detail')->orderBy('date','desc')->limit(3)->get();




        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('blog',$data);
    }

    public function blog_detail($id){

        $data['banner_image']=DB::table('banner_image')->where('page_name','blog')->get();

        $data['blog_detail']=DB::table('blog_detail')->where('id',$id)->get();

        $data['blog_detail_sb']=DB::table('blog_detail')->orderBy('date','desc')->limit(3)->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('blog_detail',$data);
    }


    public function search_blog(Request $request){

        $data['banner_image']=DB::table('banner_image')->where('page_name','blog')->get();

        $data['blog_detail_sb']=DB::table('blog_detail')->orderBy('date','desc')->limit(3)->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        $search = $request->input('search');
        if($search != ""){

        $blog_detail = DB::table('blog_detail')->where ( 'title', 'LIKE', '%' . $search . '%' )->paginate (3)->setPath ( '' );

        $pagination = $blog_detail->appends ( array (
                    'search' => $search
            ) );

        $data['blog_detail']=$blog_detail;

        if (count ( $blog_detail ) > 0){

            return view ( 'blog',$data )->withQuery ( $search );
            }
        }
        $data['blog_detail']=DB::table('blog_detail')->paginate(3);


        return view ( 'blog' ,$data)->withMessage ( 'No Details found. Try to search again !' );
        
    }




    public function courser_offered(){

        $data['banner_image']=DB::table('banner_image')->where('page_name','courser')->get();

        $data['courser_about_description']=DB::table('courser_about_description')->get();

        $data['courser_about']=DB::table('courser_about')->get();

        $courser_detail_description=DB::table('courser_detail_description')->get();

        $data['detail_image']=$courser_detail_description[0]->image;

        $data['detail_bg_image']=$courser_detail_description[0]->bg_image;

        $data['courser_detail']=DB::table('courser_detail')->get();

        $data['home_demo']=DB::table('home_demo')->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('courser_offered',$data);
    }


    public function consultation(){

        $banner_image=DB::table('banner_image')->where('page_name','consultation')->get();

        $our_astrologer=DB::table('our_astrologer')->paginate(6);

        $expertise_list=DB::table('expertise_list')->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('consultation' ,compact('banner_image','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','our_astrologer','expertise_list'))->render();
    }




    public function filter_data(Request $request){

        $banner_image=DB::table('banner_image')->where('page_name','consultation')->get();

        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        

        $filter_data = $request->search_string;
        if($filter_data != ""){

        if($filter_data == 1){

            $our_astrologer = DB::table('our_astrologer')->orderBy('experience', 'desc')->paginate (6)->setPath ( '' );

            $pagination = $our_astrologer->appends ( array (
                    'select_val' => $filter_data
            ) );

            $our_astrologer=$our_astrologer;

            $expertise_list=DB::table('expertise_list')->get();

        }
        elseif($filter_data == 2){

            $our_astrologer = DB::table('our_astrologer')->orderBy('experience')->paginate (6)->setPath ( '' );

            $pagination = $our_astrologer->appends ( array (
                    'select_val' => $filter_data
            ) );

            $our_astrologer=$our_astrologer;

            $expertise_list=DB::table('expertise_list')->get();

        }
        elseif($filter_data == 3){

            $our_astrologer = DB::table('our_astrologer')->orderBy('price', 'desc')->paginate (6)->setPath ( '' );

            $pagination = $our_astrologer->appends ( array (
                    'select_val' => $filter_data
            ) );

            $our_astrologer=$our_astrologer;

            $expertise_list=DB::table('expertise_list')->get();

        }
        elseif($filter_data == 4){

            $our_astrologer = DB::table('our_astrologer')->orderBy('price')->paginate (6)->setPath ( '' );

            $pagination = $our_astrologer->appends ( array (
                    'select_val' => $filter_data
            ) );

            $our_astrologer=$our_astrologer;

            $expertise_list=DB::table('expertise_list')->get();

        }
        else{

            $our_astrologer = DB::table('our_astrologer')->paginate (6)->setPath ( '' );

            $pagination = $our_astrologer->appends ( array (
                    'select_val' => $filter_data
            ) );

            $our_astrologer=$our_astrologer;

            $expertise_list=DB::table('expertise_list')->get();
        }

        

        if (count ( $our_astrologer ) > 0){

            

            return view('consultation_data' ,compact('banner_image','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','our_astrologer','expertise_list'))->render();
            }
        }

        $expertise_list=DB::table('expertise_list')->get();
        
        $our_astrologer=DB::table('our_astrologer')->paginate(6);


        

            return view('consultation_data' ,compact('banner_image','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','our_astrologer','expertise_list'))->render();
        
    }


    public function contact_us(){

        $data['banner_image']=DB::table('banner_image')->where('page_name','contact')->get();

        $data['contact_title']=DB::table('contact_title_description')->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('contact_us',$data);
    }


    public function login(){

        return view('login');
    }


    public function register(){

        $data['course_master']=DB::table('course_master')->get();

        return view('register',$data);
    }

    public function studentalumni(){

        $data['banner_image']=DB::table('banner_image')->where('page_name','student_alumni')->get();

        $data['student_data']=DB::table('student_alumni')->paginate(4);

        $data['student_course_list']=DB::table('student_course_list')->join('category_master','category_master.id','student_course_list.sub_category_id')->select('category_master.name as sub_name','student_course_list.studentalumni_id as studentalumni_id')->get();

        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('studentalumni',$data);
    }





    public function course_detail($id){

        $data['course_banner_image']=DB::table('course_banner_image')->where('course_id',$id)->get();

        $data['course_description']=DB::table('course_description')->where('course_id',$id)->get();

        $data['course_detail']=DB::table('course_detail')->where('course_id',$id)->get();

        $data['home_demo']=DB::table('home_demo')->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('course_detail',$data);
    }


    public function sub_course_detail($id){

        $data['sub_course_banner_image']=DB::table('sub_course_banner_image')->where('sub_course_id',$id)->get();

        $data['sub_course_description']=DB::table('sub_course_description')->where('sub_course_id',$id)->get();

        $data['sub_course_detail']=DB::table('sub_course_detail')->where('sub_course_id',$id)->get();

        $data['home_demo']=DB::table('home_demo')->get();



        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('sub_course_detail',$data);
    }


    public function faq(){

        $data['home_faq']=DB::table('home_faq')->get();

        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('faq',$data);
    }


    public function review(){

        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        return view('review');
    }


    public function submit_review(Request $request){

        $validated=$request->validate([
            'address'=>'required',
            'name'=>'required',
            'description'=>'required',
        ]);

        $address=$request->input('address');

        $name=$request->input('name');

        $description=$request->input('description');

        $file=$request->file('image');

        $imagename='';

        if($file !=''){

            $destination_path='uploads';

            $imagename=time().'_'.$file->getClientOriginalName();

            $file->move($destination_path,$imagename);

        }

        
        DB::table('home_testimonial')->insert(['image'=>$imagename,'address'=>$address , 'description'=>$description ,'name'=>$name,'status'=>0]);

        return redirect('/review')->with('error','data submitted successfully!!');
    }


    public function product($id){

        $product=DB::table('product')->where('category_id',$id)->select("product.*")->orderBy('id','Desc')->paginate(4);

        $product_sub_category=DB::table('product_sub_category')->get();

        $product_image=DB::table('product_image')->get();

        $side_product=DB::table('product')->select("product.*")->orderBy('id','Desc')->take(3)->get();

        $category=DB::table('product_category')->where('id',$id)->get();

        $cat_name = $category[0]->category;

        $banner_image=DB::table('banner_image')->where('page_name',$cat_name)->get();




        /*   Common Data   */

        $product_category=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('product', compact('product','product_sub_category','product_image','id','side_product','product_category','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','banner_image'))->render();
    }



    public function search_product(Request $request,$id){

        $product_sub_category=DB::table('product_sub_category')->get();

        $product_image=DB::table('product_image')->get();

        $side_product=DB::table('product')->select("product.*")->orderBy('id','Desc')->take(3)->get();

        $search=$request->search_string;

        $id=$request->id;

        $category=DB::table('product_category')->where('id',$id)->get();

        $cat_name = $category[0]->category;

        $banner_image=DB::table('banner_image')->where('page_name',$cat_name)->get();



        /*   Common Data   */

        $product_category=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        $product = DB::table('product')->join('product_category','product_category.id','product.category_id')->join('product_sub_category','product_sub_category.id','product.sub_category_id')->select("product.*","product_category.category as category","product_sub_category.sub_category as sub_category")
          ->where(function($query) use($search){
            $query->where('product.product_name', 'like', '%' . $search . '%')
             ->orwhere('product.price', 'like', '%' . $search . '%');
            })
          ->where('product.category_id','=',$id)
          ->orderBy('id','Desc')
          ->paginate(4);

          /*echo "<pre>";

          print_r($product);

          exit;*/



        if($product->count() >= 1){

            return view('search_product' ,compact('product','product_sub_category','product_image','id','side_product','product_category','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','banner_image'))->render();  //compact data must be in variable
        }else{

        return response()->json([

                'status'=>'nothing_found',

            ]);
         }
        
    }




    public function search_product_ck(Request $request,$id){

        $product_sub_category=DB::table('product_sub_category')->get();

        $product_image=DB::table('product_image')->get();

        $side_product=DB::table('product')->select("product.*")->orderBy('id','Desc')->take(3)->get();

        $search=$request->input('search');

        $id=$request->input('id');

        $category=DB::table('product_category')->where('id',$id)->get();

        $cat_name = $category[0]->category;

        $banner_image=DB::table('banner_image')->where('page_name',$cat_name)->get();



        /*   Common Data   */

        $product_category=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        $product = DB::table('product')->join('product_category','product_category.id','product.category_id')->join('product_sub_category','product_sub_category.id','product.sub_category_id')->select("product.*","product_category.category as category","product_sub_category.sub_category as sub_category")
          ->where(function($query) use($search){
            $query->where('product.product_name', 'like', '%' . $search . '%')
             ->orwhere('product.price', 'like', '%' . $search . '%');
            })
          ->where('product.category_id','=',$id)
          ->orderBy('id','Desc')
          ->paginate(4);

          /*echo "<pre>";

          print_r($product);

          exit;*/



        if($product->count() >= 1){

            return view('product' ,compact('product','product_sub_category','product_image','id','side_product','product_category','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','banner_image'))->render();  //compact data must be in variable
        }else{

        return redirect('/product')->with('error','nothing found');
         }
        
    }



    



    public function product_detail($id){

        $data['product']=DB::table('product')->where('id',$id)->select("product.*")->orderBy('id','Desc')->get();

        $product=DB::table('product')->where('id',$id)->select("product.*")->orderBy('id','Desc')->get();

        $category_id=$product[0]->category_id;

        $data['product_image']=DB::table('product_image')->get();

        $data['related_product']=DB::table('product')->where('category_id',$category_id)->whereNot('id',$id)->select("product.*")->orderBy('id','Desc')->get();

        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('product_detail',$data);
    }








    public function sub_product($id){

        $product=DB::table('product')->where('sub_category_id',$id)->select("product.*")->orderBy('id','Desc')->paginate(4);

        $product_sub_category=DB::table('product_sub_category')->get();

        $product_image=DB::table('product_image')->get();

        $side_product=DB::table('product')->select("product.*")->orderBy('id','Desc')->take(3)->get();

        if(count($product) !=0){

            $category_id=$product[0]->category_id;

        }else{

            $category_id="1";
        }

        

        $category=DB::table('product_category')->where('id',$category_id)->get();

        $cat_name = $category[0]->category;

        $banner_image=DB::table('banner_image')->where('page_name',$cat_name)->get();






        /*   Common Data   */

        $product_category=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        return view('sub_product', compact('product','product_sub_category','product_image','id','side_product','product_category','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','banner_image'))->render();
    }



    public function sub_search_product(Request $request,$id){

        $product_sub_category=DB::table('product_sub_category')->get();

        $product_image=DB::table('product_image')->get();

        $side_product=DB::table('product')->select("product.*")->orderBy('id','Desc')->take(3)->get();

        $search=$request->search_string;

        $id=$request->id;

        



        /*   Common Data   */

        $product_category=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        $product = DB::table('product')->join('product_category','product_category.id','product.category_id')->join('product_sub_category','product_sub_category.id','product.sub_category_id')->select("product.*","product_category.category as category","product_sub_category.sub_category as sub_category")
          ->where(function($query) use($search){
            $query->where('product.product_name', 'like', '%' . $search . '%')
             ->orwhere('product.price', 'like', '%' . $search . '%');
            })
          ->where('product.sub_category_id','=',$id)
          ->orderBy('id','Desc')
          ->paginate(4);

          /*echo "<pre>";

          print_r($product);

          exit;*/



        if(count($product) !=0){

            $category_id=$product[0]->category_id;
            
        }else{

            $category_id=1;
        }

        $category=DB::table('product_category')->where('id',$category_id)->get();

        $cat_name = $category[0]->category;

        $banner_image=DB::table('banner_image')->where('page_name',$cat_name)->get();



        if($product->count() >= 1){

            return view('sub_search_product' ,compact('product','product_sub_category','product_image','id','side_product','product_category','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','banner_image'))->render();  //compact data must be in variable
        }else{

        return response()->json([

                'status'=>'nothing_found',

            ]);
         }
        
    }




    public function sub_search_product_ck(Request $request,$id){

        $product_sub_category=DB::table('product_sub_category')->get();

        $product_image=DB::table('product_image')->get();

        $side_product=DB::table('product')->select("product.*")->orderBy('id','Desc')->take(3)->get();

        $search=$request->input('search');

        $id=$request->input('id');

        



        /*   Common Data   */

        $product_category=DB::table('product_category')->get();

        $admins=DB::table('admins')->get();

        $social_links=DB::table('social_links')->get();

        $footer_description=DB::table('footer_description')->get();

        $course_master=DB::table('course_master')->get();

        $category_master=DB::table('category_master')->where('active_cat',1)->get();

        $mytime = Carbon::now();

        $blog_detail_footer=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);

        $product = DB::table('product')->join('product_category','product_category.id','product.category_id')->join('product_sub_category','product_sub_category.id','product.sub_category_id')->select("product.*","product_category.category as category","product_sub_category.sub_category as sub_category")
          ->where(function($query) use($search){
            $query->where('product.product_name', 'like', '%' . $search . '%')
             ->orwhere('product.price', 'like', '%' . $search . '%');
            })
          ->where('product.sub_category_id','=',$id)
          ->orderBy('id','Desc')
          ->paginate(4);

          /*echo "<pre>";

          print_r($product);

          exit;*/

        if(count($product) !=0){

            $category_id=$product[0]->category_id;
            
        }else{

            $category_id=1;
        }

        $category=DB::table('product_category')->where('id',$category_id)->get();

        $cat_name = $category[0]->category;

        $banner_image=DB::table('banner_image')->where('page_name',$cat_name)->get();



        if($product->count() >= 1){

            return view('sub_product' ,compact('product','product_sub_category','product_image','id','side_product','product_category','admins','social_links','footer_description','course_master','category_master','mytime','blog_detail_footer','banner_image'))->render();  //compact data must be in variable
        }else{

        return redirect('/sub_product')->with('error','nothing found');
         }
        
    }

    public function view_cart($id){

        $data['cart_data'] = DB::table('product')->join('cart','cart.product_id','product.id')->select("product.*","cart.buyer_id as buyer_id","cart.quantity as cart_quantity","cart.id as cart_id")
          ->where('cart.buyer_id','=',$id)
          ->orderBy('id','Desc')
          ->get();

          $data['product_image']=DB::table('product_image')->get();


        /*   Common Data   */

        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);


        return view('add_cart',$data);
    }

    public function add_cart(Request $request,$id){

        $validated=$request->validate([
            'counter'=>'required',
        ]);

        $quantity=$request->input('counter');

        $buyer_id=$request->input('buyer_id');

        DB::table('cart')->insert(['buyer_id'=>$buyer_id , 'product_id'=>$id , 'quantity'=>$quantity]);

        return redirect('/view_cart/'.$buyer_id)->with('error', 'Product added to Cart !!');
    }



    public function delete_add_cart($id){

        DB::table('cart')->where('id',$id)->delete();

        return response()->json([
            'success'=>'200',
        ]);
    }
    
    
    
    
    
    
    
    
    
    
     public  function privacy_policy()
        {
             /*   Common Data   */

          $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);


            return view('privacy_policy',$data);
        }

        public function term_and_condition(){


          $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);


            return view('term_and_condition',$data);

        }

        public function cancellation_refund(){


        $data['product_category']=DB::table('product_category')->get();

        $data['admins']=DB::table('admins')->get();

        $data['social_links']=DB::table('social_links')->get();

        $data['footer_description']=DB::table('footer_description')->get();

        $data['course_master']=DB::table('course_master')->get();

        $data['category_master']=DB::table('category_master')->where('active_cat',1)->get();

        $data['mytime'] = Carbon::now();

        $data['blog_detail_footer']=DB::table('blog_detail')->orderBy('date','desc')->get()->take(2);


            return view('cancellation_refund',$data);





        }

    

}
