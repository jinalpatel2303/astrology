<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Auth;
use App\Models\Admin;
use DB;

use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ImportUser;
use App\Exports\ExportUser;
use App\Models\registration;

use App\Exports\Exportactivemember;

use App\Exports\Exportpastmember;

class MemberController extends Controller
{
    public function member_list(){

        $panding_student=DB::table('registration_master')->orderBy('r_id','Desc')->where('status',0)->paginate(10);

        return view('admin.member_list', compact('panding_student'))->render();
 
    }

    public function member_detail($id){

        $member=DB::table('registration_master')->where('r_id',$id)->get();

        $data['date']=$member[0]->date;

        $data['fname']=$member[0]->fname;
        $data['lname']=$member[0]->lname;
        $data['email']=$member[0]->email;
        $data['mobile']=$member[0]->mobile;
        $data['status']=$member[0]->status;

        $status=$member[0]->status;

        $data['apply_course']=DB::table('register_member_course')->where('member_id',$id)->get();


        $course_row=DB::table('course_master')->get();

        $data['course']=$course_row;

        if($status==1){


          $login_member=DB::table('student_login')->where('student_id',$id)->get();

          $data['enrollment']=$login_member[0]->enrollment;
          $data['username']=$login_member[0]->username;
          $data['password']=$login_member[0]->password;
        }

        return view('admin.member_detail',$data);

    }

    public function exportUsers(Request $request){

        return Excel::download(new ExportUser, 'student.xlsx');
    }

    public function Exportactivemember(Request $request){

        return Excel::download(new Exportactivemember, 'Active_member.xlsx');
    }


    public function Exportpastmember(Request $request){

        return Excel::download(new Exportpastmember, 'past_member.xlsx');
    }





    public function search_student(Request $request){

        $text=$request->search_string;

        
        $panding_student=DB::table('registration_master')->where('fname', 'like', '%' . $text . '%')->orwhere('lname', 'like', '%' . $text . '%')->orwhere('email', 'like', '%' . $text . '%')->orwhere('mobile', 'like', '%' . $text . '%')->paginate(10); 
 

        if($panding_student->count() >= 1){

            return view('admin.member_search' ,compact('panding_student'))->render();  //compact data must be in variable
        }else{

            return response()->json([
                    'status'=>'nothing_found',
                ]);
        }

    }



    public function active_membar(){


        $active_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->where('is_expire',0)->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email", "registration_master.mobile as mobile")->paginate(10); 


        return view('admin.active_membar', compact('active_student_data'))->render();
        
    }


    public function search_active_student(Request $request){

        $text=$request->search_string;

        /*$active_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->where('student_login.is_expire',0)->orwhere('registration_master.fname', 'like', '%' . $text . '%')->orwhere('registration_master.lname', 'like', '%' . $text . '%')->orwhere('registration_master.email', 'like', '%' . $text . '%')->orwhere('student_login.enrollment', 'like', '%' . $text . '%')->orwhere('registration_master.mobile', 'like', '%' . $text . '%')->orwhere('student_login.username', 'like', '%' . $text . '%')->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email", "registration_master.mobile as mobile")->paginate(10);*/
        
        /*$active_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->where('student_login.is_expire',0)->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email","registration_master.mobile as mobile")->paginate(10);*/ 

        $active_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->orwhere('registration_master.fname', 'like', '%' . $text . '%')->where('student_login.is_expire',0)->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email","registration_master.mobile as mobile")->paginate(10); 
 

        if($active_student_data->count() >= 1){

            return view('admin.active_member_search' ,compact('active_student_data'))->render();  //compact data must be in variable
        }else{

            return response()->json([
                'status'=>'nothing_found',
            ]);
        }
    }

    public function past_member(){


        $past_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->where('is_expire',1)->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email", "registration_master.mobile as mobile")->paginate(10); 


        return view('admin.past_member', compact('past_student_data'))->render();

    }

    public function search_past_student(Request $request){


        $text=$request->search_string;

        /*$active_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->where('student_login.is_expire',0)->orwhere('registration_master.fname', 'like', '%' . $text . '%')->orwhere('registration_master.lname', 'like', '%' . $text . '%')->orwhere('registration_master.email', 'like', '%' . $text . '%')->orwhere('student_login.enrollment', 'like', '%' . $text . '%')->orwhere('registration_master.mobile', 'like', '%' . $text . '%')->orwhere('student_login.username', 'like', '%' . $text . '%')->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email", "registration_master.mobile as mobile")->paginate(10); */
        
        $past_student_data=DB::table('student_login')->join('registration_master','registration_master.r_id','student_login.student_id')->where('registration_master.fname', 'like', '%' . $text . '%')
                                    ->orwhere('registration_master.lname', 'like', '%' . $text . '%')
                                    ->orwhere('registration_master.email', 'like', '%' . $text . '%')
                                    ->orwhere('student_login.enrollment', 'like', '%' . $text . '%')
                                    ->orwhere('registration_master.mobile', 'like', '%' . $text . '%')
                                    ->orwhere('student_login.username', 'like', '%' . $text . '%')
                                    ->select("student_login.*","registration_master.fname as fname","registration_master.lname as lname","registration_master.email as email", "registration_master.mobile as mobile")->where('student_login.is_expire',1)->paginate(10); 
 

        if($past_student_data->count() >= 1){

            return view('admin.past_member_search' ,compact('past_student_data'))->render();  //compact data must be in variable
        }else{

            return response()->json([
                'status'=>'nothing_found',
            ]);
        }
    }
}
